package softlond.juegoCartas.cartas.enumedor;

public enum Valor {
    DOS, TRES, CUATRO, CINCO, SEIS, SIETE, OCHO, NUEVE, DIEZ, JACK, REINA, REY, AS

}
