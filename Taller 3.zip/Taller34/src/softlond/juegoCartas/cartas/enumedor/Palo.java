package softlond.juegoCartas.cartas.enumedor;

public enum Palo {
    CORAZONES, DIAMANTES, TREBOLES, PICAS
}
