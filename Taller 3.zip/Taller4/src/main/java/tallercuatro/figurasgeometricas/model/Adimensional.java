package main.java.tallercuatro.figurasgeometricas.model;

public class Adimensional  {

    
    public String Definicion() {     
        
        return "El punto Describe posicion en el plano";
    }
    
}
