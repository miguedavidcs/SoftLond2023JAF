package main.java.tallercuatro.figurasgeometricas.model.interfaces;

public interface Planos {
    double calcularArea();
    double calcularPerimetro();
    
    
    
}
