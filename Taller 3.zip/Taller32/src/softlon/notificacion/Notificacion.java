package softlon.notificacion;

public interface Notificacion {
   public void enviar();
    
}
