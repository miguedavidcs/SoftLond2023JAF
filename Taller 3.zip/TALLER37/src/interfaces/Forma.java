package interfaces;

public interface  Forma {
    double Area();
}
