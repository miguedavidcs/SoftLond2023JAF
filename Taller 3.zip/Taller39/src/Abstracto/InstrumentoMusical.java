package Abstracto;

public abstract class InstrumentoMusical {
    public abstract void tocar();
}
