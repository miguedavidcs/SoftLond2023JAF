package Interfaces;

public interface Cuerdas {
    void tieneCuerdas();
    
}
