package Exceptions;

public class TiendaException extends Exception{
    public TiendaException(String mensaje){
        super(mensaje);
    }
}
