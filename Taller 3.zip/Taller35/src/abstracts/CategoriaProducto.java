package abstracts;

public abstract class CategoriaProducto {
    public String nombreCategoria;
    public abstract void mostrarCategoria();
    public String getNombreCategoria() {
        return nombreCategoria;
    }
    
}
