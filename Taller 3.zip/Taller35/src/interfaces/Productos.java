package interfaces;

public interface Productos {
    double calcularPrecio();
    void mostrarDetalles();
}
