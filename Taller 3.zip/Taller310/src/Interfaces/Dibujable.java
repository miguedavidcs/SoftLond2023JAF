package Interfaces;

public interface Dibujable {
    void dibujar();
    
}
