package Model;

import Abstracta.Figura;

public class Rectangulo extends Figura {
    @Override
    public void dibujar() {
        System.out.println("Dibujando un rectángulo");
    }
}
