package Abstracta;

import Interfaces.Dibujable;

public abstract class Figura implements Dibujable{
    
}
