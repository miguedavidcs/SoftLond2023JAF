package implementos;

public interface Comportamiento {
    void Correr();
    void Saltar();
    void Volar();
}
