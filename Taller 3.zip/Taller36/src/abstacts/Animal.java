package abstacts;

public abstract class Animal {
    public abstract void hacersonido();
}
