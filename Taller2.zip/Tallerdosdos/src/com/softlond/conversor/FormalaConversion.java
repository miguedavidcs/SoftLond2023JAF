package com.softlond.conversor;


public class FormalaConversion {
    public static double convertir(double cantidad, double tasaDe, double tasaA) {
        return (cantidad / tasaDe) * tasaA;
    }
}

